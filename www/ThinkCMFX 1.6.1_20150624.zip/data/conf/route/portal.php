<?php	return array (
  'news' => 'portal/list/index?id=1',
  'article/:id\d' => 'portal/article/index',
);